import PokemonList from "./components/PokemonList"
import "./App.css"

function App() {
  return (
    <>
      <PokemonList />
    </>
  )
}

export default App