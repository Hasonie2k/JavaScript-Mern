import React, { useState } from 'react';
import UserForm from './components/UserForm';

function App() {
    const [submittedUser, setSubmittedUser] = useState(null);

    const handleUserSubmit = (user) => {
        setSubmittedUser(user);
    };

    return (
        <div className="App">
            <h1>User Registration Form</h1>
            <UserForm props={handleUserSubmit} />
            {submittedUser && (
                <div>
                    <h2>Submitted User Details:</h2>
                    <p>First Name: {submittedUser.firstName}</p>
                    <p>Last Name: {submittedUser.lastName}</p>
                    <p>Email: {submittedUser.email}</p>
                    <p>Password: {submittedUser.password}</p>
                    <p>Confirm Password: {submittedUser.confirmPassword}</p>
                </div>
            )}
        </div>
    );
}

export default App;
