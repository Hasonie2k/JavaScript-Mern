import React, { useState } from 'react';

const UserForm = (props) => {
    const [firstName, setFirstName] = useState("");
    const [lastName, setLastName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");  
    const [firstNameError, setFirstNameError] = useState("");
    const [lastNameError, setLastNameError] = useState("");
    const [emailError, setEmailError] = useState("");
    const [passwordError, setPasswordError] = useState("");
    const [confirmPasswordError, setConfirmPasswordError] = useState("");
    
    const validateFirstName = () => {
        if (firstName === "") {
            setFirstNameError("First Name is required");
        } else {
            setFirstNameError("");
        }
    };
    
    const validateLastName = () => {
        if (lastName === "") {
            setLastNameError("Last Name is required");
        } else {
            setLastNameError("");
        }
    };
    
    const validateEmail = () => {
        const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        if (!emailPattern.test(email)) {
            setEmailError("Invalid email format");
        } else {
            setEmailError("");
        }
    };
    
    const validatePassword = () => {
        if (password === "") {
            setPasswordError("Password is required");
        } else {
            setPasswordError("");
        }
    };
    
    const validateConfirmPassword = () => {
        if (confirmPassword === "") {
            setConfirmPasswordError("Confirm Password is required");
        } else if (confirmPassword !== password) {
            setConfirmPasswordError("Passwords do not match");
        } else {
            setConfirmPasswordError("");
        }
    };
    
    const createUser = (e) => {
        e.preventDefault();

        validateFirstName();
        validateLastName();
        validateEmail();
        validatePassword();
        validateConfirmPassword();

        if (firstNameError || lastNameError || emailError || passwordError || confirmPasswordError) {
            return;
        }

        const newUser = {
            firstName,
            lastName,
            email,
            password
        };
        console.log("Welcome", newUser);

        // Clear the form after submission
        setFirstName("");
        setLastName("");
        setEmail("");
        setPassword("");
        setConfirmPassword("");

        // Pass the submitted user to the parent component using props
        props.props(newUser);
    };
    
    return (
        <div>
            <form onSubmit={createUser}>
                <div>
                    <label>First Name: </label> 
                    <input type="text" value={firstName} onBlur={validateFirstName} onChange={(e) => setFirstName(e.target.value)} />
                    {firstNameError && <span>{firstNameError}</span>}
                </div>
                <div>
                    <label>Last Name: </label> 
                    <input type="text" value={lastName} onBlur={validateLastName} onChange={(e) => setLastName(e.target.value)} />
                    {lastNameError && <span>{lastNameError}</span>}
                </div>
                <div>
                    <label>Email Address: </label> 
                    <input type="text" value={email} onBlur={validateEmail} onChange={(e) => setEmail(e.target.value)} />
                    {emailError && <span>{emailError}</span>}
                </div>
                <div>
                    <label>Password: </label>
                    <input type="password" value={password} onBlur={validatePassword} onChange={(e) => setPassword(e.target.value)} />
                    {passwordError && <span>{passwordError}</span>}
                </div>
                <div>
                    <label>Confirm Password: </label>
                    <input type="password" value={confirmPassword} onBlur={validateConfirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} />
                    {confirmPasswordError && <span>{confirmPasswordError}</span>}
                </div>
                <input type="submit" value="Create User" />
            </form>
        </div>
    );
};

export default UserForm;
