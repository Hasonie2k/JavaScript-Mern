import React from 'react';

const PersonCard = (props) => {
    return (
        <div>
        <h1>{ props.firstname } {props.lastname}</h1>
        <h2>age: { props.age }</h2>
        <h3>hair color: { props.hair }</h3>
        </div>
    )
}

export default PersonCard; 