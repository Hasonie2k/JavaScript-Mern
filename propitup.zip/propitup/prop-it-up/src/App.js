import './App.css';
import PersonCard from './components/PersonCard';


function App() {
  return (
    <div className="App">
        <PersonCard 
        firstname={"doe"} lastname={"jane"}
        age={45} hair={"black"}/>

        <PersonCard 
        firstname={"smith"} lastname={"john"}
        age={88} hair={"brown"}/>

        <PersonCard 
        firstname={"fillmore"} lastname={"millard"}
        age={50} hair={"brown"}/>

        <PersonCard 
        firstname={"smith"} lastname={"maria"}
        age={62} hair={"brown"}/>
    </div>
  );
}

export default App;
